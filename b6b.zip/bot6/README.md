# EvilMC
This is a discord bot that crashes minecraft servers using exploits.
> It does not work on all servers.

# Requiments
[Node.js 16.6.0 or higher](https://nodejs.org/en/download/)

[Discord.js v13](https://discord.js.org "Discord.js v13")

[node-os-utils](https://www.npmjs.com/package/node-os-utils "node-os-utils")

[moment](https://www.npmjs.com/package/moment "moment")

[tree-kill](https://www.npmjs.com/package/tree-kill)

[minecraft-server-util](https://www.npmjs.com/package/minecraft-server-util)

# Commands
> Default prefix ";"

* Other
  * botping - Pong!
  * vpsusage - Checking used cpu and memory on vps
  * about -About bot

* Crashers
  * avarion - Usage (avarion ip:port)
  * nullping - Usage (nullping ip:port)
  * extreme - Usage (extreme ip:port type) types: [byte1, byte2]
  * auth - Usage (auth ip:port)

> Language bot: Russian

# Screenshot
![AboutScreen](https://user-images.githubusercontent.com/31757032/150298339-bb227406-0ae9-4095-befd-818726378b3a.png)

# Example
[Example using this bot](https://www.youtube.com/watch?v=5_bqOTMevdg)

# ToDo
 * New method crashers
 * Add working proxies
 * Bots...
 * Slash Commands (Done!)
 * Optimize code
 * Multilanguage support

> The list will be updated

# Support Author
DonationAlerts: https://www.donationalerts.com/r/desconnet

# I am in...
[VK](https://vk.com/endnet)

[YouTube](https://youtube.com/DesConnet)

Discord: DesConnet#6768
